package com.calmresponse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirRouteSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
